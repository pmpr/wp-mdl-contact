<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660693016c486             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Contact\Model\Model; use Pmpr\Module\Contact\Widget\Widget; class Contact extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\103\157\x6e\164\x61\x63\164", PR__MDL__CONTACT); }]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto cuykwgmswkskqkyi; } Setting::symcgieuakksimmu(); cuykwgmswkskqkyi: if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kuicqywysciceggs; } Ajax::symcgieuakksimmu(); kuicqywysciceggs: Hook::symcgieuakksimmu(); Page::symcgieuakksimmu(); Model::symcgieuakksimmu(); Widget::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\163\x74\x72\x75\143\164\x75\x72\x65\144\55\x64\141\164\141")) { goto mkwskuycuyguqqok; } StructuredData::symcgieuakksimmu(); mkwskuycuyguqqok: } }
