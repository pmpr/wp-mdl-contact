<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65ef35b3f14a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Contact\Model\Model; use Pmpr\Module\Contact\Widget\Widget; class Contact extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\103\157\156\x74\x61\x63\x74", PR__MDL__CONTACT); }]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto cuykwgmswkskqkyi; } Setting::symcgieuakksimmu(); cuykwgmswkskqkyi: if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kuicqywysciceggs; } Ajax::symcgieuakksimmu(); kuicqywysciceggs: Hook::symcgieuakksimmu(); Page::symcgieuakksimmu(); Model::symcgieuakksimmu(); Widget::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\163\x74\x72\x75\143\164\x75\x72\x65\x64\x2d\144\x61\164\x61")) { goto mkwskuycuyguqqok; } StructuredData::symcgieuakksimmu(); mkwskuycuyguqqok: } }
