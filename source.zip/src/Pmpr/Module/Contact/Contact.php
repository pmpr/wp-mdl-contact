<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d47625d1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Contact\Model\Model; use Pmpr\Module\Contact\Widget\Widget; class Contact extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x43\157\156\164\141\143\164", PR__MDL__CONTACT); }]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto iqcogmsguwoikame; } Setting::symcgieuakksimmu(); iqcogmsguwoikame: if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto gimmuoqwckiseaik; } Ajax::symcgieuakksimmu(); gimmuoqwckiseaik: Hook::symcgieuakksimmu(); Page::symcgieuakksimmu(); Model::symcgieuakksimmu(); Widget::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\x73\164\x72\165\143\x74\165\x72\x65\144\55\x64\141\164\141")) { goto cmqucgoewuyieoyk; } StructuredData::symcgieuakksimmu(); cmqucgoewuyieoyk: if (!$this->omseesogaocascyo("\x73\x65\x63\165\162\151\164\171")) { goto yqykqysmiquwoasu; } Security::symcgieuakksimmu(); yqykqysmiquwoasu: } }
