<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada7da657d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\Contact\Model\Model; use Pmpr\Module\Contact\Widget\Widget; class Contact extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x43\157\x6e\164\x61\143\164", PR__MDL__CONTACT); }]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto qmeoaqmsuseueqiy; } Setting::symcgieuakksimmu(); qmeoaqmsuseueqiy: if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto ygkcacsyyckescqs; } Ajax::symcgieuakksimmu(); ygkcacsyyckescqs: Hook::symcgieuakksimmu(); Page::symcgieuakksimmu(); Model::symcgieuakksimmu(); Widget::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\163\164\x72\x75\143\164\165\162\145\144\x2d\144\x61\164\x61")) { goto cuoqqgaygogsmmic; } StructuredData::symcgieuakksimmu(); cuoqqgaygogsmmic: if (!$this->omseesogaocascyo("\x73\145\x63\165\162\151\164\x79")) { goto cgewcsueoyaeikgm; } Security::symcgieuakksimmu(); cgewcsueoyaeikgm: } }
