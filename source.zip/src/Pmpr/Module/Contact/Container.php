<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65f00a7794aed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const wqimawoummkeeugk = "\143\x6f\156\x74\141\x63\164\x5f"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
