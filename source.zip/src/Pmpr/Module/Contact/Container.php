<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65edae861addb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const wqimawoummkeeugk = "\x63\157\156\x74\x61\143\164\137"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
