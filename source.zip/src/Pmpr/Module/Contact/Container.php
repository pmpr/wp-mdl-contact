<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd2155db163             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const wqimawoummkeeugk = "\143\157\x6e\x74\x61\143\x74\137"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
