<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65eec0ffc50c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const wqimawoummkeeugk = "\143\x6f\156\x74\141\x63\164\137"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
