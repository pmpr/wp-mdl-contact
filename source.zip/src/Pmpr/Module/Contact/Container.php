<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a3d6ddd0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const wqimawoummkeeugk = 'contact_'; }
