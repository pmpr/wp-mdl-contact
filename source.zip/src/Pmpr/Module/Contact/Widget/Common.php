<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65eec0ffc50c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Widget; use Pmpr\Common\Foundation\Widget; use Pmpr\Module\Contact\Traits\SettingTrait; abstract class Common extends Widget { use SettingTrait; }
