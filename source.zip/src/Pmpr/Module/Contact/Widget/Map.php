<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf7a04349e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Widget; use Exception; class Map extends Common { public function __construct() { parent::__construct(__("\115\141\x70", PR__MDL__CONTACT), __("\x44\151\163\160\x6c\x61\x79\40\x74\150\145\x20\155\x61\160\x2e", PR__MDL__CONTACT)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::sogmkkcwuamuqegw)->gswweykyogmsyawy(__("\110\145\151\147\150\164", PR__MDL__CONTACT))->escqqisecooswqgo()); } public function gayqqwwuycceosii($ywmkwiwkosakssii = [], $owgumcsyqsamiemg = []) : array { $qookweymeqawmcwo = []; if (!($qmcuiciekkawmmms = $this->ikiwgimsoiwswmeo())) { goto igymseewwyiocoug; } $cswemwoyesycwkuq = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($owgumcsyqsamiemg, self::sogmkkcwuamuqegw, 300); try { $qmcuiciekkawmmms = $this->caokeucsksukesyo()->gkksucgseqqemesc()->qcgocuceocquqcuw($qmcuiciekkawmmms, ["\151\146\x72\x61\155\145" => [self::sogmkkcwuamuqegw => $cswemwoyesycwkuq]]); } catch (Exception $wgaoewqkwgomoaai) { } $qookweymeqawmcwo["\x6d\141\x70"] = $qmcuiciekkawmmms; igymseewwyiocoug: return $qookweymeqawmcwo; } }
