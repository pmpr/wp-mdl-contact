<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65ef35b3f14a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Widget; use Exception; class Map extends Common { public function __construct() { parent::__construct(__("\x4d\141\160", PR__MDL__CONTACT), __("\x44\x69\163\160\x6c\x61\x79\40\x74\x68\145\40\x6d\x61\x70\56", PR__MDL__CONTACT)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::sogmkkcwuamuqegw)->gswweykyogmsyawy(__("\110\x65\151\x67\x68\164", PR__MDL__CONTACT))->escqqisecooswqgo()); } public function gayqqwwuycceosii($ywmkwiwkosakssii = [], $owgumcsyqsamiemg = []) : array { $qookweymeqawmcwo = []; if (!($qmcuiciekkawmmms = $this->ikiwgimsoiwswmeo())) { goto eegqyykygiccaoeo; } $cswemwoyesycwkuq = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($owgumcsyqsamiemg, self::sogmkkcwuamuqegw, 300); try { $qmcuiciekkawmmms = $this->caokeucsksukesyo()->gkksucgseqqemesc()->qcgocuceocquqcuw($qmcuiciekkawmmms, ["\151\146\x72\x61\x6d\x65" => [self::sogmkkcwuamuqegw => $cswemwoyesycwkuq]]); } catch (Exception $wgaoewqkwgomoaai) { } $qookweymeqawmcwo["\x6d\141\x70"] = $qmcuiciekkawmmms; eegqyykygiccaoeo: return $qookweymeqawmcwo; } }
