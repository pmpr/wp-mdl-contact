<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646aa29538cf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Widget; use Exception; class Map extends Common { public function __construct() { parent::__construct(__("\115\141\160", PR__MDL__CONTACT), __("\x44\x69\163\x70\154\141\x79\x20\x74\150\145\40\x6d\141\x70\56", PR__MDL__CONTACT)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::sogmkkcwuamuqegw)->gswweykyogmsyawy(__("\110\145\x69\x67\x68\x74", PR__MDL__CONTACT))->escqqisecooswqgo()); } public function gayqqwwuycceosii($ywmkwiwkosakssii = [], $owgumcsyqsamiemg = []) : array { $qookweymeqawmcwo = []; if (!($qmcuiciekkawmmms = $this->ikiwgimsoiwswmeo())) { goto ygcsmkuycoagwyou; } $cswemwoyesycwkuq = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($owgumcsyqsamiemg, self::sogmkkcwuamuqegw, 300); try { $qmcuiciekkawmmms = $this->caokeucsksukesyo()->gkksucgseqqemesc()->qcgocuceocquqcuw($qmcuiciekkawmmms, ["\151\146\162\141\155\145" => [self::sogmkkcwuamuqegw => $cswemwoyesycwkuq]]); } catch (Exception $wgaoewqkwgomoaai) { } $qookweymeqawmcwo["\155\141\x70"] = $qmcuiciekkawmmms; ygcsmkuycoagwyou: return $qookweymeqawmcwo; } }
