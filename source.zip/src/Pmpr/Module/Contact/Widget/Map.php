<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada7da657d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Widget; use Exception; class Map extends Common { public function __construct() { parent::__construct(__("\x4d\x61\160", PR__MDL__CONTACT), __("\x44\x69\163\160\x6c\x61\171\x20\x74\150\x65\40\155\x61\x70\56", PR__MDL__CONTACT)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::sogmkkcwuamuqegw)->gswweykyogmsyawy(__("\110\145\151\147\150\164", PR__MDL__CONTACT))->escqqisecooswqgo()); } public function gayqqwwuycceosii($ywmkwiwkosakssii = [], $owgumcsyqsamiemg = []) : array { $qookweymeqawmcwo = []; if (!($qmcuiciekkawmmms = $this->ikiwgimsoiwswmeo())) { goto qcessicwuikwqsis; } $cswemwoyesycwkuq = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($owgumcsyqsamiemg, self::sogmkkcwuamuqegw, 300); try { $qmcuiciekkawmmms = $this->caokeucsksukesyo()->gkksucgseqqemesc()->qcgocuceocquqcuw($qmcuiciekkawmmms, ["\x69\x66\162\141\x6d\x65" => [self::sogmkkcwuamuqegw => $cswemwoyesycwkuq]]); } catch (Exception $wgaoewqkwgomoaai) { } $qookweymeqawmcwo["\x6d\x61\x70"] = $qmcuiciekkawmmms; qcessicwuikwqsis: return $qookweymeqawmcwo; } }
