<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65edae861addb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Widget; use Exception; class Map extends Common { public function __construct() { parent::__construct(__("\115\141\160", PR__MDL__CONTACT), __("\x44\x69\x73\160\154\141\171\40\x74\x68\145\x20\x6d\141\x70\x2e", PR__MDL__CONTACT)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::sogmkkcwuamuqegw)->gswweykyogmsyawy(__("\x48\145\x69\147\x68\164", PR__MDL__CONTACT))->escqqisecooswqgo()); } public function gayqqwwuycceosii($ywmkwiwkosakssii = [], $owgumcsyqsamiemg = []) : array { $qookweymeqawmcwo = []; if (!($qmcuiciekkawmmms = $this->ikiwgimsoiwswmeo())) { goto eegqyykygiccaoeo; } $cswemwoyesycwkuq = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($owgumcsyqsamiemg, self::sogmkkcwuamuqegw, 300); try { $qmcuiciekkawmmms = $this->caokeucsksukesyo()->gkksucgseqqemesc()->qcgocuceocquqcuw($qmcuiciekkawmmms, ["\151\146\x72\x61\x6d\145" => [self::sogmkkcwuamuqegw => $cswemwoyesycwkuq]]); } catch (Exception $wgaoewqkwgomoaai) { } $qookweymeqawmcwo["\155\141\x70"] = $qmcuiciekkawmmms; eegqyykygiccaoeo: return $qookweymeqawmcwo; } }
