<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae89147262             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\x65\146\157\x72\145\137\162\145\156\144\x65\x72\x5f\x62\x72\x61\x6e\144\137\163\x63\x68\x65\155\x61", [$this, "\x6e\x67\x61\141\147\141\x63\151\x79\147\157\x6b\163\153\145\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto sciwggaeogcoesiu; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, Constants::auqoykcmsiauccao)); mkwskuycuyguqqok: } kuicqywysciceggs: sciwggaeogcoesiu: return $ciyacayigmkuskgg; } }
