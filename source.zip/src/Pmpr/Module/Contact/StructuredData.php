<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669f592b286de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\x65\x66\x6f\162\145\137\x72\145\x6e\144\145\x72\x5f\x62\x72\141\x6e\144\137\163\143\150\x65\155\x61", [$this, "\x6e\147\141\x61\147\x61\x63\x69\x79\147\157\x6b\x73\153\x65\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto qkcyqocqqwmqgqww; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([self::aisguagukaewucii => self::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, self::auqoykcmsiauccao)); ssoucoucsgccekwe: } qqewoyookaskiuek: qkcyqocqqwmqgqww: return $ciyacayigmkuskgg; } }
