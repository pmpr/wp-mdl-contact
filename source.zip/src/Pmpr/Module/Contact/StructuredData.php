<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71daf34b6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebSite; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . 'before_render_website_schema', [$this, 'waemuuekyoooykgg']); } public function waemuuekyoooykgg($ukuqoigggaqaosoy) { if ($ukuqoigggaqaosoy instanceof WebSite) { $mcmgyiyokmuwqoyc = $ukuqoigggaqaosoy->eicocscgqssuowue(); if ($mcmgyiyokmuwqoyc) { $naiuumgusmkcowsa = $this->kmuweyayaqoeqiyw()->yeokamaagskewssa([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $mcmgyiyokmuwqoyc->sceiycyikekgiqgg($kyocyoemugcyqqyu[Constants::auqoykcmsiauccao] ?? ''); } } } return $ukuqoigggaqaosoy; } }
