<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f8064ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\145\146\x6f\162\145\137\162\x65\156\x64\x65\162\x5f\142\x72\141\156\x64\137\x73\143\x68\x65\155\141", [$this, "\156\147\x61\x61\x67\x61\x63\x69\171\x67\x6f\153\163\x6b\x65\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto yowsmsiyimmimemc; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([self::aisguagukaewucii => self::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, self::auqoykcmsiauccao)); kwagwqyusyiyoaqs: } eqkauqciwewmgeoi: yowsmsiyimmimemc: return $ciyacayigmkuskgg; } }
