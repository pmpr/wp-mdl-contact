<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbd2290d2e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\145\146\157\162\x65\137\162\145\x6e\144\145\x72\137\x62\x72\x61\x6e\144\137\163\143\150\145\x6d\141", [$this, "\x6e\x67\x61\141\x67\x61\143\151\x79\x67\x6f\153\163\153\145\147"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { if ($ciyacayigmkuskgg instanceof Brand) { $naiuumgusmkcowsa = $this->kmuweyayaqoeqiyw()->yeokamaagskewssa([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($kyocyoemugcyqqyu[Constants::auqoykcmsiauccao] ?? ''); } } return $ciyacayigmkuskgg; } }
