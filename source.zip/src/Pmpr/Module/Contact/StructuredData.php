<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf7a04349e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\x65\146\157\x72\145\137\162\x65\x6e\144\145\162\x5f\142\x72\x61\156\x64\x5f\x73\x63\x68\x65\x6d\x61", [$this, "\156\x67\141\141\147\x61\x63\x69\x79\x67\x6f\x6b\x73\153\x65\147"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto cuoqqgaygogsmmic; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([self::aisguagukaewucii => self::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, self::auqoykcmsiauccao)); ygkcacsyyckescqs: } qmeoaqmsuseueqiy: cuoqqgaygogsmmic: return $ciyacayigmkuskgg; } }
