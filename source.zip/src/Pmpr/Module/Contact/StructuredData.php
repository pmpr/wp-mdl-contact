<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d47625d1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\x65\146\x6f\x72\145\137\x72\x65\x6e\x64\145\x72\137\x62\162\x61\x6e\144\x5f\163\143\150\x65\x6d\141", [$this, "\156\147\x61\x61\x67\x61\143\151\x79\147\x6f\x6b\163\153\145\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto eegqyykygiccaoeo; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([self::aisguagukaewucii => self::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, self::auqoykcmsiauccao)); miyqyeiwquwsacsm: } qkcyqocqqwmqgqww: eegqyykygiccaoeo: return $ciyacayigmkuskgg; } }
