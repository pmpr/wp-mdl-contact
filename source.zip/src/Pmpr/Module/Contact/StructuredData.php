<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400c221c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\x65\x66\x6f\x72\x65\x5f\162\x65\x6e\144\x65\x72\x5f\x62\x72\141\156\x64\137\163\x63\150\145\155\x61", [$this, "\x6e\147\141\x61\147\x61\x63\151\x79\147\x6f\153\x73\153\x65\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto yowsmsiyimmimemc; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([self::aisguagukaewucii => self::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, self::auqoykcmsiauccao)); kwagwqyusyiyoaqs: } eqkauqciwewmgeoi: yowsmsiyimmimemc: return $ciyacayigmkuskgg; } }
