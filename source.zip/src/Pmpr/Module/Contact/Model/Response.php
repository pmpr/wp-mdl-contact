<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400c221c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\x73\x75\142\155\151\x73\x73\151\x6f\x6e\137\151\144"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\122\145\x73\x70\x6f\x6e\x73\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\122\x65\163\x70\157\x6e\x73\145\x73", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(self::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\x73\145\162", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(self::eoskkkieowogacws)->gswweykyogmsyawy(__("\115\x65\x73\x73\x61\147\145", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\x53\x75\142\x6d\x69\163\163\x69\x6f\x6e", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
