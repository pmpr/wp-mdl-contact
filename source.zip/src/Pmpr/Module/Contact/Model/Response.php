<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65f00a7794aed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\163\165\x62\155\151\x73\163\151\157\x6e\x5f\151\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\122\145\x73\x70\x6f\x6e\163\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\x52\145\163\160\x6f\x6e\x73\x65\x73", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(self::meksegaoamowuwoq)->gswweykyogmsyawy(__("\x55\163\145\x72", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(self::eoskkkieowogacws)->gswweykyogmsyawy(__("\x4d\145\x73\163\x61\x67\x65", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\x53\165\x62\x6d\x69\x73\x73\151\157\156", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
