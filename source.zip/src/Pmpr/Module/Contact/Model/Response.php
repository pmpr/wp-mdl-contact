<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1177a96ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\x73\165\x62\x6d\151\x73\163\151\157\156\x5f\x69\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\122\x65\x73\x70\157\156\x73\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\x52\x65\x73\x70\x6f\156\163\x65\x73", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(Constants::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\163\145\x72", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(Constants::eoskkkieowogacws)->gswweykyogmsyawy(__("\x4d\x65\163\163\x61\x67\145", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\x53\165\142\155\151\163\163\x69\x6f\156", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
