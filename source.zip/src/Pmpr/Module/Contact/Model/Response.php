<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae89147262             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\163\165\x62\x6d\x69\x73\x73\x69\157\156\137\151\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\x52\x65\x73\160\x6f\156\x73\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\122\145\163\160\x6f\156\x73\145\x73", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(Constants::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\163\145\162", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(Constants::eoskkkieowogacws)->gswweykyogmsyawy(__("\x4d\145\163\163\141\x67\x65", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\x53\x75\x62\x6d\151\163\x73\151\x6f\x6e", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
