<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65eec0ffc50c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\163\x75\x62\x6d\151\163\163\x69\157\x6e\137\x69\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\122\145\x73\160\x6f\156\163\x65", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\122\145\163\x70\157\x6e\163\145\x73", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(self::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\163\x65\x72", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(self::eoskkkieowogacws)->gswweykyogmsyawy(__("\115\x65\x73\x73\x61\x67\x65", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\123\165\142\155\x69\163\x73\x69\157\x6e", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
