<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65edae861addb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\x73\165\x62\x6d\151\163\163\x69\157\156\137\151\144"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\122\x65\163\x70\157\156\x73\x65", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\x52\x65\163\x70\157\x6e\163\x65\163", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(self::meksegaoamowuwoq)->gswweykyogmsyawy(__("\x55\x73\x65\x72", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(self::eoskkkieowogacws)->gswweykyogmsyawy(__("\x4d\145\x73\x73\x61\x67\x65", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\123\x75\x62\155\151\163\x73\151\157\x6e", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
