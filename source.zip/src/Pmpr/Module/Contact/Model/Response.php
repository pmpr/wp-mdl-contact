<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660693016c486             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\163\x75\142\x6d\151\163\163\x69\157\x6e\137\x69\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\x52\x65\x73\160\157\x6e\163\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\122\x65\x73\160\x6f\x6e\x73\x65\163", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(self::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\163\145\162", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(self::eoskkkieowogacws)->gswweykyogmsyawy(__("\x4d\145\163\x73\141\147\x65", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\x53\165\x62\x6d\151\163\163\x69\157\x6e", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
