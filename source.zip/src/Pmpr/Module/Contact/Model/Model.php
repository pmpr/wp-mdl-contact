<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65eebe89918ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Module\Contact\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Response::symcgieuakksimmu(); Submission::symcgieuakksimmu(); } }
