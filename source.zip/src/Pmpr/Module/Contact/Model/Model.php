<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf7a04349e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Module\Contact\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Response::symcgieuakksimmu(); Submission::symcgieuakksimmu(); } }
