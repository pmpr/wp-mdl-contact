<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f8064ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Module\Contact\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Response::symcgieuakksimmu(); Submission::symcgieuakksimmu(); } }
