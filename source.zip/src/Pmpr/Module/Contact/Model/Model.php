<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d47625d1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Module\Contact\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Response::symcgieuakksimmu(); Submission::symcgieuakksimmu(); } }
