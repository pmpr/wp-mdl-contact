<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1177a96ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Module\Contact\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Response::symcgieuakksimmu(); Submission::symcgieuakksimmu(); } }
